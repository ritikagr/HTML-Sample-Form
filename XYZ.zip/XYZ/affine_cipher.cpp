#include<iostream>
using namespace std;

int gcdExtended(int a,int b,int &x,int &y)
{
	int x1,y1;

	if(a==0)
	{
	x = 0;y = 1;
	return b;
	}
	int gcd = gcdExtended(b%a,a,x1,y1);

	x = y1 - (b/a)*x1;
	y = x1;

	return gcd;
}

int mi(int a,int n)
{

	int x,y;
	int g = gcdExtended(a,n,x,y);

	if(g!=1)
	return -1;
	else
	return (x%n+n)%n;
}

int main()
{
	string pt,cp;
	cout<<"Input Plain Text: ";
	cin>>pt;
	cp = "";
	int k1,k2;
	cin>>k1>>k2;
	
	int n = pt.length();
	
	for(int i=0;i<n;i++)
	{
		int x = ((pt[i]-'A')*k1+k2)%26;
		
		cp += (char)('A'+x);
	}
	
	cout<<"Cipher Text: "<<cp<<endl;

	cout<<"Input Cipher Text: ";
	cin>>cp;
	pt="";
	int ki = mi(k1,26);
	
	for(int i=0;i<cp.length();i++)
	{
		int x = (((cp[i]-'A' - k2)*ki)%26 + 26)%26;
		
		pt += (char)('A'+x);
	}
	
	cout<<pt<<endl;
}
