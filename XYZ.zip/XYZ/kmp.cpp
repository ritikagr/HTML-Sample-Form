#include<iostream>
#include<vector>
using namespace std;

void calculateLPS(vector<int>& lps,string s,int n)
{
    int i = 1,len = 0;
    lps[0] = 0;
    while(i<n)
    {
        if(s[i] == s[len])
        {
            len++;
            lps[i] = len;
            i++;
        }
        else
        {
            if(len == 0)
            {
                i++;
            }
            else
            {
                len = lps[len-1];
            }
        }
    }
}

int main()
{
    string txt,pat;
    cin>>txt>>pat;
    int l1 = txt.length();
    int l2 = pat.length();
    int i = 0,j = 0;
    vector<int> lps(l2+1);
    calculateLPS(lps,pat,l2);
    for(i = 0;i<l1;)
    {
        if(txt[i] == pat[j])
        {
            i++;
            j++;
        }
        else
        {
            if(j == 0)
            {
                i++;
            }
            else
            {
                j = lps[j-1];
            }
        }
        if(j == l2)
        {
            cout<<"Pattern match found at "<<i-l2<<"\n";
            j = lps[j-1]+1;
        }
    }
}
