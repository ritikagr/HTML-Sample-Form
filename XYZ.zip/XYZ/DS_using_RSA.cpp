#include<bits/stdc++.h>
using namespace std;

int phi(int p,int q)
{
	return (p-1)*(q-1);
}

int pow(int x,int y,int mod)
{
	int res = 1;

	while(y)
	{
		if(y & 1)
			res = (res*x)%mod;
		x = (x*x)%mod;
		y/=2;
	}
	return res;
}

void mi(int a,int b,int &g,int &x,int &y)
{
	if(b==0)
	{
		g = a;
		x = 1;
		y = 0;
		return;
	}
	int g1,x1,y1;
	mi(b,a%b,g1,x1,y1);
	g = g1;
	x = y1;
	y = x1-(a/b)*y1;
}
int main()
{
	int p,q,e,m;

	cout<<"p: ";
	cin>>p;
	cout<<"q: ";
	cin>>q;
	cout<<"e: ";
	cin>>e;
	cout<<"m: ";
	cin>>m;
	int n = p*q;
	int ln = phi(p,q);
	int d,x,y;
	mi(e, ln, x,d,y);
	if(d<0)
	d = (d%ln+ln)%ln;
	cout<<"d:"<<d<<endl;

	int S = pow(m,d,n);
	cout<<"Signature created by Alice: "<<S<<endl;

	cout<<"Alice is sending M and S to Bob..."<<endl;

	cout<<"Bob is decrypting the Signature..."<<endl;

	int m1 = pow(S,e,n);

	cout<<"Message decrypted by Bob: "<<m1<<endl;

	if(m==m1)
	cout<<"Signature is valid"<<endl;
	else
	cout<<"Signature is Invalid"<<endl;
}
