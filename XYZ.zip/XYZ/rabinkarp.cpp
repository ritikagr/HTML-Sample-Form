#include<iostream>
using namespace std;

int expo(int base,int exp,int mod)
{
	int ans = 1;
	while(exp)
	{
		if(exp&1)
		{
			ans = (ans*base)%mod;
		}
		base = (base*base)%mod;
		exp = exp/2;
	}
	return ans;
}

int main()
{
	int i,j,k;
	string pat,txt;
	cout<<"Enter the text and pattern\n";
	cin>>txt>>pat;
	int n = txt.length();
	int m = pat.length();
	int p = 0,t = 0,d = 10,q = 13,h = 0;
	h = expo(d,m-1,q);
	for(i = 0;i<m;i++)
	{
		p = ((p*d)%q+pat[i])%q;
		t = ((t*d)%q+txt[i])%q;
	}
	//cout<<p<<" "<<t<<"\n";
	for(i = 0;i<=n-m;i++)
	{
		if(t == p)
		{
			bool pos = true;
			for(j = 0;j<m;j++)
			{
				if(pat[j] != txt[j+i])
				{
					pos = false;
				}
			}
			if(pos == true)
			{
				cout<<"Match at "<<i<<"\n";
			}
			else
			{
				cout<<"Spurious match at "<<i<<" "<<txt.substr(i,m)<<"\n";
			}
		}
		if(i<(n-m))
		t = (((t-(h*txt[i])%q)*d)%q+txt[i+m])%q;
	}
}
