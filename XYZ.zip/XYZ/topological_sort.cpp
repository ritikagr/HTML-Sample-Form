#include<bits/stdc++.h>
using namespace std;

void topoSort(int x,vector<vector<int> > v,int n,bool *vis,stack<int> &st)
{

    vis[x] = true;

    for(int i=0;i<v[x].size();i++)
    {
    if(!vis[v[x][i]])
    topoSort(v[x][i],v,n,vis,st);
    }

    st.push(x);

}

int main()
{

    int n,e;
    cin>>n>>e;

    vector<vector<int> > V(n);
    int u,v;
    for(int i=0;i<e;i++)
    {
    cin>>u>>v;

    V[u].push_back(v);
    }

    bool vis[n];

    memset(vis,false,sizeof(vis));
    stack<int> st;
    for(int i=0;i<n;i++)
    {
    if(!vis[i])
    topoSort(i,V,n,vis,st);
    }

    while(!st.empty())
    {
    cout<<st.top()<<" ";
    st.pop();
    }
}
