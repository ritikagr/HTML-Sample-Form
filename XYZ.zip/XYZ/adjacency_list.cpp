#include<iostream>
#include<vector>
using namespace std;

int main()
{
	int n,e,i,j,k;
	cin>>n>>e;
	int u,v;
	vector<vector<int> > vec(n+1);
	for(i = 1;i<=e;i++)
	{
		cin>>u>>v;
		vec[u].push_back(v);
	}
	cout<<"Adjacency list representation : \n";
	for(i = 1;i<=n;i++)
	{
		cout<<i<<" --> ";
		int ln = vec[i].size();
		for(j = 0;j<ln;j++)
		{
			cout<<vec[i][j]<<" ";
		}
		cout<<"\n";
	}
}
