#include<iostream>
#include<algorithm>
using namespace std;

string expand(string s)
{
	string temp;
	temp.push_back(s[7]);
	int i;
	for(i = 0;i<8;i++)
	{
		temp.push_back(s[i]);
	}
	temp.push_back(s[0]);
	return temp;
}

string fun(string s1,string s2)
{
	string ans;
	int n,m,i,k;
	for(i = 0;i<10;i++)
	{
		n = s1[i]-'0';
		m = s2[i]-'0';
		k = n^m;
		ans.push_back(k+'0');
	}
	return ans;
}

string compress(string s)
{
	int sbox[4][8],i,j;
	int arr[32];
	for(i = 0;i<16;i++)
	{
		arr[i] = i;
		arr[i+16] = i;
	}
	random_shuffle(arr,arr+32);
	for(i = 0;i<7;i++)
	{
		for(j = 0;j<4;j++)
		{
			sbox[j][i] = arr[j*8+i];
		}
	}

	int lrow = 0,lcol = 0;
	for(i = 1;i<4;i++)
	{
		lcol = lcol*2+(s[i]-'0');
	}

	lrow = 2*(s[0]-'0')+(s[4]-'0');

	int rrow = 0,rcol = 0;
	for(i = 6;i<9;i++)
	{
		rcol = rcol*2+(s[i]-'0');
	}
	rrow = 2*(s[5]-'0')+(s[9]-'0');
	int l = sbox[lrow][lcol];
	int r = sbox[rrow][rcol];

	string ans = "";
	for(i = 0;i<4;i++)
	{
		ans = (char)(r%2 + '0') + ans;
		r = r/2;
	}
	for(i = 0;i<4;i++)
	{
		ans = (char)(l%2 + '0') + ans;
		l = l/2;
	}
	
	return ans;
}

int main()
{
	string ip,key;
	cin>>ip>>key;
	string lpt = ip.substr(0,8);
	string rpt = ip.substr(8,8);

	string intermed = expand(rpt);

	intermed = fun(rpt,key);

	string lans = compress(intermed);

	int n,m,k,i;
	for(i = 0;i<8;i++)
	{
		n = lans[i];
		m = lpt[i];
		k = n^m;
		lpt[i] = k+'0';
	}
	string rans = lpt;
	cout<<"Encrypted text : "<<lans<<rans<<"\n";
}
