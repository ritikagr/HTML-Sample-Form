#include<bits/stdc++.h>
//#include<windows.h>
using namespace std;

int main()
{
	cout<<"Alice sends request to Authentication server\n"<<endl;
	//Sleep(4000);
	
	cout<<"Authentication server sends ticket T1 to ALice which is key between AS and TGS\n"<<endl;
	//Sleep(4000);
	
	cout<<"Alice uses T1 to communicate with TGS\n"<<endl;
	//Sleep(4000);
	
	cout<<"TGS sends Alice a Key KAB to communicate with Bob\n"<<endl;
	//Sleep(4000);
		
	cout<<"Alice started communication with Bob using Key KAB\n"<<endl;
	//Sleep(4000);
	
	cout<<"Alice is communicating with Bob..."<<endl;
	//Sleep(10000);
}
