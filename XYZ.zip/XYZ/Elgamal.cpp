#include<iostream>
#include<cstdlib>
#include<vector>
#include<time.h>
using namespace std;

int expo(int base,int exp,int mod)
{
	int ans = 1;
	while(exp)
	{
		if(exp&1)
		{
			ans = (ans*base)%mod;
		}
		base = (base*base)%mod;
		exp = exp/2;
	}
	return ans;
}

int findGen(int p)
{
	int i;
	for(i = 1;i<p;i++)
	{
		vector<bool> visited(p,false);
		int count = 1;
		int prod = i;
		while(count<p)
		{
			prod = (prod*i)%p;
			if(visited[prod])
			{
				break;
			}
			else
			{
				visited[prod] = true;
				count++;
			}
		}
		if(count == p)
		{
			return i;
		}
	}
	return 0;
}

int main()
{
	int p,e1,e2,c1,c2,m,r,d;
	cout<<"Enter a large prime number p ";
	cin>>p;
	srand(time(NULL));
	cout<<"Generating generator element of "<<p<<"... ";
	e1 = findGen(p);
	cout<<e1<<"\n";
	d = rand()%(p-2)+1;
	cout<<"Generating private key of B... ";
	e2 = expo(e1,d,p);
	cout<<e2<<"\n";
	cout<<"B is sending key to A... ("<<e1<<","<<e2<<","<<p<<")\n";
	cout<<"A generates a random number r in Z(p-1)... ";
	r = rand()%(p-1);
	cout<<r<<"\n";
	cout<<"Enter the plaintext message ";
	cin>>m;
	c1 = expo(e1,r,p);
	c2 = (expo(e2,r,p)*m)%p;
	cout<<"A sends the encrypted message to B... ("<<c1<<","<<c2<<")\n";
	cout<<"B receives the ciphertext...\n";
	m = expo(c1,d,p);
	m = expo(m,p-2,p);
	m = (m*c2)%p;
	cout<<"Decrypted message at B = "<<m<<"\n";
}
