#include<iostream>
#include<vector>
#include<climits>
#include<stack>
using namespace std;

void dfs(int v,stack<int>& s,vector<bool>& visited,vector<pair<int,int> > *vec,int n)
{
	visited[v] = true;
	int ln = vec[v].size(),i,x;
	for(i = 0;i<ln;i++)
	{
		x = vec[v][i].first;
		if(!visited[x])
		{
			dfs(x,s,visited,vec,n);
		}
	}
	s.push(v);
}

vector<int> topologicalSort(vector<pair<int,int> > *vec,int n)
{
	stack<int> s;
	vector<bool> visited(n+1,false);
	int i;
	for(i = 1;i<=n;i++)
	{
		if(!visited[i])
		{
			dfs(i,s,visited,vec,n);
		}
	}
	vector<int> v;
	while(!s.empty())
	{
		v.push_back(s.top());
		s.pop();
	}
	return v;
}

void distDfs(int source,vector<pair<int,int> > *vec,int *dist,vector<int>& parent,int n)
{
	int ln = vec[source].size(),i,j,k;
	for(i = 0;i<ln;i++)
	{
		j = vec[source][i].first;
		if(dist[j]>dist[source]+vec[source][i].second)
		{
			dist[j] = dist[source]+vec[source][i].second;
			parent[j] = source;
		}
	}
}

int main()
{
	int i,j,k,n,e,source,u,v,w;
	cout<<"Enter no. of vertices and edges\n";
	cin>>n>>e;
	cout<<"Enter all the edges u v w\n";
	vector<pair<int,int> > vec[n+1];
	for(i = 1;i<=e;i++)
	{
		cin>>u>>v>>w;
		vec[u].push_back(make_pair(v,w));
	}
	vector<int> ts;
	ts = topologicalSort(vec,n);
	int dist[n+1];
	for(i = 0;i<=n;i++)
	{
		dist[i] = 100000000;
	}
	cout<<"Enter the source vertex\n";
	cin>>source;
	dist[source] = 0;
	for(i = 0;i<n&&ts[i] != source;i++)
	{
	}
	vector<int> parent(n+1,-1);
	for(;i<=n;i++)
	{
		distDfs(ts[i],vec,dist,parent,n);
	}
	for(i = 1;i<=n;i++)
	{
		cout<<dist[i]<<" : "<<parent[i]<<"--->"<<i<<"\n";
	}
}
