#include<iostream>
#include<vector>
using namespace std;

struct edge{
	int u,v,w;
};

int main()
{
	int i,j,k,n,e,u,v,w,x,y;
	cout<<"Enter no. of vertices and edges\n";
	cin>>n>>e;
	cout<<"Enter all the edges u v w\n";
	vector<edge> vec(e+1);
	for(i = 1;i<=e;i++)
	{
		cin>>u>>v>>w;
		vec[i].u = u;
		vec[i].v = v;
		vec[i].w = w;
	}
	vector<int> dist(n+1,1000007);
	int src;
	cout<<"Enter the source vertex\n";
	cin>>src;
	dist[src] = 0;
	bool found;
	vector<int> par(n+1);
	for(i = 1;i<n;i++)
	{
		found = false;
		for(j = 1;j<=e;j++)
		{
			if(dist[vec[j].v]>dist[vec[j].u]+vec[j].w)
			{
				dist[vec[j].v] = dist[vec[j].u]+vec[j].w;
				found = true;
				par[vec[j].v] = vec[j].u;
			}
		}
		if(!found)
		{
			break;
		}
	}
	found = false;
	for(j = 1;j<=e;j++)
	{
		if(dist[vec[j].v]>dist[vec[j].u]+vec[j].w)
		{
			found = true;
			break;
		}
	}
	if(found == true)
	{
		cout<<"Negative edges present\n";
		for(i = 1;i<=n;i++)
		{
			cout<<dist[i]<<" ";
		}
		cout<<"\npath\n";
		for(i = 1;i<=n;i++)
		{
			cout<<par[i]<<"-->"<<i<<"\n";
		}
		cout<<"\n";
	}
	else
	{
		for(i = 1;i<=n;i++)
		{
			cout<<dist[i]<<" ";
		}
		cout<<"\npath\n";
		for(i = 1;i<=n;i++)
		{
			cout<<par[i]<<"-->"<<i<<"\n";
		}
		cout<<"\n";
	}
}
