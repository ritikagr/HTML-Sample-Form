#include<bits/stdc++.h>
using namespace std;

struct node
{
        int data,degree;
        node *parent,*child,*sibling;
        node(int x)
        {
                data = x; degree = 0;
                parent = NULL; child = NULL; sibling = NULL;
        }
};

node* mergeBTree(node *a,node *b)
{
        if(a->data > b->data)
        {
                node *t = a;
                a = b;
                b = t;
        }

        b->parent = a;
        b->sibling = a->child;
        a->degree++;
        a->child = b;

        return a;
}

list<node*> unionBinomialHeap(list<node*> h1,list<node*> h2)
{
        list<node*> heap;

        list<node*>::iterator t1;
        list<node*>::iterator t2;

        t1 = h1.begin(); t2 = h2.begin();
        while(t1!=h1.end() && t2!=h2.end())
        {
                if((*t1)->degree <= (*t2)->degree)
                {
                        heap.push_back(*t1);
                        t1++;
                }
                else
                {
                        heap.push_back(*t2);
                        t2++;
                }
        }

        while(t1!=h1.end())
        {
                heap.push_back(*t1);
                t1++;
        }

        while(t2!=h2.end())
        {
                heap.push_back(*t2);
                t2++;
        }

        return heap;
}

list<node*> adjust(list<node*> h)
{
        list<node*>::iterator a;
        list<node*>::iterator b;
        list<node*>::iterator c;

        if(h.size()==1)
        return h;
        else if(h.size()==2)
        {
                a = h.begin();
                b = a; b++;
                c = h.end();
        }
        else
        {
                a = h.begin();
                b = a; b++;
                c = b; c++;
        }

        while(b!=h.end())
        {

                if((*a)->degree != (*b)->degree)
                {
                        a++; b++;
                        if(c!=h.end())
                        c++;
                }
                else
                {
                        if(c!=h.end() && (*b)->degree==(*c)->degree)
                        {
                                a++;b++;c++;
                        }
                        else
                        {
                                *a = mergeBTree(*a, *b);
                                b = h.erase(b);
                                if(c!=h.end())
                                c++;
                        }
                }
        }

        return h;
}

list<node*> insert(list<node*> bheap,int key)
{
        node *temp = new node(key);
        list<node*> theap;
        theap.push_back(temp);

        bheap = unionBinomialHeap(bheap, theap);

        bheap = adjust(bheap);
        return bheap;
}

node *getMin(list<node*> h)
{
        list<node*>::iterator it;
        it = h.begin();
        node *temp = NULL;
        if(it==h.end())
        {
                cout<<"Empty Binomial Heap"<<endl;
                return temp;
        }

        temp = *it;

        while(it!=h.end())
        {
                if((*it)->data < temp->data)
                temp = *it;

                it++;
        }
        return temp;
}

list<node*> removeMinimumFromTree(node *tree)
{
        list<node*> theap;

        node *t = tree->child;

        node *temp;

        while(t)
       {
                temp = t;
                t = t->sibling;
                temp->sibling = NULL;
                theap.push_front(temp);
        }

        return theap;
}

list<node*> extractMin(list<node*> h)
{
        node *temp = getMin(h);

        if(temp==NULL)
        return h;

        list<node*> heap;

        list<node*>::iterator it;
        it = h.begin();

        while(it!=h.end())
        {
                if((*it)!=temp)
                heap.push_back(*it);
                it++;
        }

        list<node*> theap = removeMinimumFromTree(temp);
        h = unionBinomialHeap(heap, theap);
        h = adjust(h);

        return h;
}

void printTree(node *t)
{
        while(t)
        {
               cout<<t->data<<" ";
                printTree(t->child);
                t = t->sibling;
        }
}

void printHeap(list<node*> h)
{
        list<node*>::iterator it;
        it = h.begin();

        while(it!=h.end())
        {
                printTree(*it);
                it++;
        }
}

int main()
{
        list<node*> bheap;

        cout<<"Insert 1"<<endl;
        cout<<"Get Minimum 2"<<endl;
        cout<<"Print Heap 3"<<endl;
        cout<<"Extract Minimum 4"<<endl;

        int t;
        cout<<"enter number of operations to perform:";
        cin>>t;

        while(t--)
        {
                int x;
                cin>>x;

                if(x==1)
                {
                        int key;
                        cout<<"Enter key to insert: ";
                        cin>>key;
                        bheap = insert(bheap, key);
                }
                else if(x==2)
                {
                        node *temp = getMin(bheap);
                        cout<<"Minimum element in Binomial Heap is : "<<temp->data<<endl;
                }
                else if(x==3)
                {
                        cout<<"Binomial heap:"<<endl;
                        printHeap(bheap);
                        cout<<endl;
                }
                else if(x==4)
                {
                        cout<<"Extracting Minimum Element from Binomial Heap..."<<endl;
                        bheap = extractMin(bheap);
                        printHeap(bheap);
                        cout<<endl;
                }
        }
        return 0;
}
