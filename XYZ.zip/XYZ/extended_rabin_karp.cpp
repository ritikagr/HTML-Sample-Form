#include<bits/stdc++.h>
#include<string.h>
using namespace std;
#define d 10
int rabink(char T[],char P[])
{
int flag=0;
int q = 13;
int M = strlen(P);
int N = strlen(T);
int i, j;
int p = 0;
int t = 0;
int h = 1;
for (i = 0; i < M-1; i++)
h = (h*d)%q;
for (i = 0; i < M; i++)
{
p = (d*p + P[i])%q;
t = (d*t + T[i])%q;
}
for (i = 0; i <= N - M; i++)
{
if (p== t)
{
for (j = 0; j < M; j++)
{
if (T[i+j] != P[j])
break;
}
if (j == M)
{
printf("Pattern found at index %d \n", i);
flag=1;
}
else printf("spurious found at %d\n",i);
}
if ( i < N-M )
{
t = (d*(t - T[i]*h) + T[i+M])%q;
if(t < 0)
t = (t + q);
}
}
return flag;
}
int main()
{
    int nop;
    char T[80],P[100][10];
    printf("Enter the text string: ");
    cin>>T;
    cout<<"Enter Number of Patterns\n";
    cin>>nop;
    cout<<"Enter patterns"<<endl;
    for(int i=0;i<nop;i++)
    cin>>P[i];
    int flag=0;
    for(int i=0;i<nop;i++)
    {
    cout<<"Pattern "<<(i+1)<<":\n";
    int res=rabink(T,P[i]);
    if(res==1)
    flag=1;
    }
    if(flag==1)
    cout<<"Some pattern is present"<<endl;
    else
    cout<<"No pattern was matched\n"<<endl;
    return 0;
}
