#include<iostream>
#include<vector>
using namespace std;

int main()
{
	int n,i,j,k;
	cin>>n;
	vector<vector<int> > vec(n+1,vector<int>(n+1));
	for(i = 1;i<=n;i++)
	{
		for(j = 1;j<=n;j++)
		{
			cin>>vec[i][j];
		}
	}
	vector<vector<int> > pie(n+1,vector<int>(n+1,-1));
	for(k = 1;k<=n;k++)
	{
		for(i = 1;i<=n;i++)
		{
			for(j = 1;j<=n;j++)
			{
				if(vec[i][j]>vec[i][k]+vec[k][j])
				{
					vec[i][j] = vec[i][k]+vec[k][j];
					pie[i][j] = k;
				}
			}
		}
	}
	cout<<"Final Matrix :\n";
	for(i = 1;i<=n;i++)
	{
		for(j = 1;j<=n;j++)
		{
			cout<<vec[i][j]<<" ";
		}
		cout<<"\n";
	}
	cout<<"Pie matrix :\n";
	for(i = 1;i<=n;i++)
	{
		for(j = 1;j<=n;j++)
		{
			cout<<pie[i][j]<<" ";
		}
		cout<<"\n";
	}
}
