#include<iostream>
using namespace std;

int gcd(int a,int b)
{
	if(b == 0)
	{
		return a;
	}
	return gcd(b,a%b);
}

int gcdExtended(int a,int b,int &x,int &y)
{
	int x1,y1;

	if(a==0)
	{
	x = 0;y = 1;
	return b;
	}
	int gcd = gcdExtended(b%a,a,x1,y1);

	x = y1 - (b/a)*x1;
	y = x1;

	return gcd;
}

int mi(int a,int n)
{

	int x,y;
	int g = gcdExtended(a,n,x,y);

	if(g!=1)
	return -1;
	else
	return (x%n+n)%n;
}

string decrypt(string ct,int a,int b)
{
	int ma = mi(a,26),i,ln = ct.length(),num;

	string pt;
	for(i = 0;i<ln;i++)
	{
		num = ct[i]-'A';
		num = ((ma*(num+26-b))%26+26)%26;
		pt.push_back(num+'A');
	}
	return pt;
}

int main()
{
	int a,b;
	string pt,ct;
	cin>>ct;
	bool found = false;
	for(a = 1;a<26;a++)
	{
		for(b = 0;b<26;b++)
		{
			if(gcd(a,26) == 1)
			{
				pt = decrypt(ct,a,b);
				cout<<"Key:("<<a<<", "<<b<<") Plain Text = "<<pt<<endl;
			}
		}
	}
}
