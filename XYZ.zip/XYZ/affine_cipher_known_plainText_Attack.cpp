#include<iostream>
using namespace std;

int gcd(int a,int b)
{
	if(b == 0)
	{
		return a;
	}
	return gcd(b,a%b);
}

int gcdExtended(int a,int b,int &x,int &y)
{
	int x1,y1;

	if(a==0)
	{
	x = 0;y = 1;
	return b;
	}
	int gcd = gcdExtended(b%a,a,x1,y1);

	x = y1 - (b/a)*x1;
	y = x1;

	return gcd;
}

int mi(int a,int n)
{

	int x,y;
	int g = gcdExtended(a,n,x,y);

	if(g!=1)
	return -1;
	else
	return (x%n+n)%n;
}

int main()
{
string pt;
cin>>pt;
string s;
cin>>s;
int n=s.length();
int c[n],p[n];
for(int i=0;pt[i];i++)
p[i]=pt[i]-'a';
for(int i=0;s[i];i++)
c[i]=s[i]-'A';
int d[n];
int m[]={1,3,5,7,9,11,15,17,19,21,23,25};

for(int i=0;i<26;i++)
{
	if(gcd(i,26)==1)
	for(int j=0;j<26;j++)
	{

	int m1=mi(i,26);

	for(int k=0;k<n;k++)
	d[k]=(((c[k]-j+26)%26)*m1)%26;
	int k;
	for(k=0;k<n;k++)
	if(d[k]!=p[k])
	{
	break;
	}
	if(k==n)
	{
	cout<<i<<" "<<j<<endl;
	return 0;
	}
	}
}

return 0;
}
