#include<iostream>
using namespace std;

int main()
{
	double x1,y1,x2,y2,x3,y3,a,b;
	cin>>x1>>y1;
	cin>>x2>>y2;
	cin>>a;
	double lambda = ((y2-y1)/(x2-x1));
	x3 = lambda*lambda-x1-x2;
	y3 = lambda*(x1-x3)-y1;
	cout<<"R' by point addition = ("<<x3<<","<<y3<<")\n";
	lambda = (3*x1*x1+a)/(2*y1);
	x3 = lambda*lambda-x1-x2;
	y3 = lambda*(x1-x3)-y1;
	cout<<"R' by point doubling = ("<<x3<<","<<y3<<")\n";
}
