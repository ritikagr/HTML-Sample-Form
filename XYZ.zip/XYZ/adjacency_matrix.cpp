#include<iostream>
using namespace std;

int main()
{
	int n,e,i,j,k;
	cin>>n>>e;
	int u,v;
	int adj[n+1][n+1];
	for(i = 0;i<=n;i++)
	{
		for(j = 0;j<=n;j++)
		{
			adj[i][j] = 0;
		}
	}
	for(i = 1;i<=e;i++)
	{
		cin>>u>>v;
		adj[u][v] = 1;
	}
	for(i = 1;i<=n;i++)
	{
		for(j = 1;j<=n;j++)
		{
			cout<<adj[i][j]<<" ";
		}
		cout<<"\n";
	}
}
