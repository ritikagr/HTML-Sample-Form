#include<bits/stdc++.h>
using namespace std;

struct node
{
    int data;
    node *left,*right;
    node(int x)
    {
        data = x;
        left = NULL;
        right = NULL;
    }
};

void inorderTr(node *root)
{
    if(!root)
    return;
    
    inorderTr(root->left);
    cout<<root->data<<" ";
    inorderTr(root->right);
}

void insertion(node* &root,int x)
{
    node *newnode = new node(x);
    if(!root)
    {
        root = new node(x);
        return;
    }
    
    node *ptr = root;
    node *prev = NULL;
    while(ptr)
    {
        prev = ptr;
        if(x<ptr->data)
        ptr = ptr->left;
        else
        ptr = ptr->right;
    }
    
    if(x<prev->data)
    prev->left = newnode;
    else
    prev->right = newnode;
}

node *deletion(node* root,int x)
{
    if(!root)
    return root;
    
    if(x<root->data)
    root->left = deletion(root->left,x);
    else if(x>root->data)
    root->right = deletion(root->right,x);
    else
    {
        if(!root->left)
        {
            node *t = root->right;
            free(root);
            return t;
        }
        else if(!root->right)
        {
            node *t = root->left;
            free(root);
            return t;
        }
        
        node *suc = root->right;
        while(!suc->left)
        {
            suc = suc->left;
        }
    
        root->data = suc->data;
        root->right = deletion(root->right,suc->data);
    }
    
    return root;
}

int main()
{
    node *root = NULL;
    
    int t;
    cin>>t;
    
    cout<<"Enter 0 for Insertion"<<endl;
    cout<<"Enter 1 for deletion"<<endl;
    cout<<"Enter 2 for inorder traversal"<<endl;
    
    while(t--)
    {
        int c;
        cin>>c;
        
        switch(c)
        {
            case 0:
            cout<<"Enter any number to insert in BST: ";
            int x;
            cin>>x;
            insertion(root,x);
            break;
            case 1:
            cout<<"Enter any number to delete in BST: ";
            cin>>x;
            root = deletion(root,x);
            inorderTr(root);
            break;
            case 2:
            cout<<"inorder Traversal of BST"<<endl;
            inorderTr(root);
            cout<<endl;
            break;
        }
    }    
}