#include<bits/stdc++.h>
using namespace std;

int expo(int base,int exp,int mod)
{
	int ans = 1;
	while(exp)
	{
		if(exp&1)
		{
			ans = (ans*base)%mod;
		}
		base = (base*base)%mod;
		exp = exp/2;
	}
	return ans;
}

int main()
{
	int p,g,x,y,r1,r2;
	cout<<"Enter the prime number p shared between Alice and Bob and an integer g less than p ";
	cin>>p>>g;
	cout<<"Enter private keys of Alice and Bob less than g ";
	cin>>x>>y;
	r1 = expo(g,x,p);
	cout<<"Public key calculated by Alice = "<<r1<<endl;
	r2 = expo(g,y,p);
	cout<<"Public key calculated by Bob = "<<r2<<endl;
	int r1t = expo(r2,x,p);
	r2 = expo(r1,y,p);
	cout<<"Alice receives Bob's public key...\n";
	cout<<"Bob receives Alice's public key...\n";\
	cout<<"Shared secret key calculated by Alice = "<<r1t<<endl;
	cout<<"Shared secret key calculated by Bob = "<<r2<<endl;
	cout<<"Finally both have same shared secret key\n";
}
