#include<iostream>
#include<cstdlib>
using namespace std;

int main()
{
	int ida,idb,ra,ya,ka,yb,kb;
	cout<<"Enter ids of two users between whom communication needs to be done\n";
	cin>>ida>>idb;
	ra = rand()%10;
	cout<<"Alice sends request to KDC (IDa,IDb,ra)\n";
	int ks = rand()%10;
	int t = rand()%10;
	cout<<"KDC generates its session key "<<ks<<"\n";
	cout<<"KDC encrypts the requests and sends it to A "<<"ya = Eka(ks,ra,t,idb) and yb = Ekb(ks,t,idb)\n";
	ya = ka+ks+ra*10+t*100+idb*1000;
	yb = kb+ks+t*10+idb*100;
	cout<<"KDC sends ya,yb to Alice ("<<ya<<","<<yb<<") ---> Alice\n";
	cout<<"Alice decrypts the message sent by KDC\n";
	cout<<"Alice sends verification message to Bob (yab,yb)\n";
	cout<<"Bob decrypts yb using its private key yb\n";
	cout<<"Bob decrypts yab using session key ks obtained from above decryption\n";
	cout<<"Bob verifies if IDa'' is equal to IDa'\n";
}
