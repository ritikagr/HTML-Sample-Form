#include<iostream>
#include<vector>
using namespace std;

int main()
{
	int i,j,k,n,e,u,v;
	cout<<"Enter the no. of vertices\n";
	cin>>n;
	vector<vector<int> > vec(n+1,vector<int>(n+1,0));
	cout<<"Enter the boolean matrix\n";
	for(i = 1;i<=n;i++)
	{
		for(j = 1;j<=n;j++)
		{
			cin>>vec[i][j];
		}
	}
	for(i = 1;i<=n;i++)
	{
		vec[i][i] = 1;
	}
	for(k = 1;k<=n;k++)
	{
		for(i = 1;i<=n;i++)
		{
			for(j = 1;j<=n;j++)
			{
				if(vec[i][j] == 0&&vec[i][k] == 1&&vec[k][j] == 1)
				{
					vec[i][j] = 1;
				}
			}
		}
	}
	for(i = 1;i<=n;i++)
	{
		for(j = 1;j<=n;j++)
		{
			cout<<vec[i][j]<<" ";
		}
		cout<<"\n";
	}
}
