#include<bits/stdc++.h>
using namespace std;

struct comp{
	bool operator()(const pair<int,int>& p1,pair<int,int>& p2)
	{
		return p1.first<p2.first;
	}
};

int main()
{
	int n,i,j,k,x,y,e,u,v,w;
	cout<<"Enter no. of vertices and edges\n";
	cin>>n;
	vector<pair<int,int> > vec[n+1];
	cin>>e;
	cout<<"Enter all the edges u v w\n";
	for(i = 0;i<e;i++)
	{
		cin>>u>>v>>w;
		vec[u].push_back(make_pair(v,w));
	}
	vector<int> dist(n+1,1000007);
	int src;
	cout<<"Enter the source vertex\n";
	cin>>src;
	priority_queue<pair<int,int>,vector<pair<int,int> >,comp>  pq;
	dist[src] = 0;
	pq.push(make_pair(0,src));
	vector<int> par(n+1);
	par[src] = -1;
	while(!pq.empty())
	{
		pair<int,int> p = pq.top();
		pq.pop();
		x = p.first;
		y = p.second;
		int sz = vec[y].size();
		for(i = 0;i<sz;i++)
		{
			v = vec[y][i].first;
			w = vec[y][i].second;
			if(dist[v]>dist[y]+w)
			{
				dist[v] = dist[y]+w;
				pq.push(make_pair(dist[v],v));
				par[v] = y;
			}
		}
	}
	for(i = 1;i<=n;i++)
	{
		cout<<dist[i]<<" ";
	}
	cout<<"\nPath\n";
	for(i = 1;i<=n;i++)
	{
		cout<<par[i]<<"-->"<<i<<"\n";
	}
	cout<<"\n";
}


