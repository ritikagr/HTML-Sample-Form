#include<mpi.h>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main(int argc,char** argv)
{
	MPI_Init(&argc,&argv);
	int world_size,world_rank;
	MPI_Comm_size(MPI_COMM_WORLD,&world_size);
	MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);
	MPI_Status status;
	int n,i,val;
	int arr[world_size];
	int k;
	if(world_rank == 0)
	{
		printf("Enter elements\n");
		for(i = 0;i<n;i++)
		{
			scanf("%d",&arr[i]);
		}
		k = log2(n);
		if(1<<k != n)
		{
			k++;
		}
	}
	MPI_Bcast(&k,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Bcast(arr,n,MPI_INT,0,MPI_COMM_WORLD);
	printf("In %d process\n",world_rank);
	printf("k = %d\n",k);
	for(i = 0;i<k;i++)
	{
		if(world_rank+(1<<i)<n)
		{
			printf("Process %d sending to %d...\n",world_rank,world_rank+(1<<i));
			MPI_Send(&arr[world_rank],1,MPI_INT,world_rank+(1<<i),0,MPI_COMM_WORLD);
			printf("Process %d sent data to process %d\n",world_rank,world_rank+(1<<i));
		}
		if(world_rank-(1<<i)>=0)
		{
			MPI_Recv(&val,1,MPI_INT,world_rank-(1<<i),0,MPI_COMM_WORLD,&status);
			printf("Process %d receives data from process %d\n",world_rank,world_rank-(1<<i));
			arr[world_rank] += val;
		}
		MPI_Barrier(MPI_COMM_WORLD);
	}
	if(world_rank>0)
	MPI_Send(&arr[world_rank],1,MPI_INT,0,0,MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
	if(world_rank == 0)
	{
		printf("Prefix sum : ");
		for(i = 0;i<n;i++)
		{
			if(i>0)
			MPI_Recv(&arr[i],1,MPI_INT,i,0,MPI_COMM_WORLD,&status);
			printf("%d ",arr[i]);
		}
		printf("\n");
	}
	MPI_Finalize();
}
