#include <stdio.h>
#include <math.h>
#include "mpi.h"

const int MAX=1000;

int main(int argc, char **argv) {
  int rank, size;
  MPI_Status status;

  int arr[MAX];
  int i, count;
  int A, B,value[2];
	
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank); 
  MPI_Comm_size(MPI_COMM_WORLD, &size); 
	
  if(rank==0) 
  {
    printf("Initial array: ");
    for (i=0;i<size;i++) 
    {
      scanf("%d",&arr[i]);
    }
    printf("\n");
  }

  MPI_Scatter(arr,1,MPI_INT,value, 1, MPI_INT, 0, MPI_COMM_WORLD);

  for(i=0;i<size;i++) 
  {
    if(i%2 == 0) 
    {
      if(rank%2 == 0) 
	{
		MPI_Send(&value[0],1,MPI_INT,rank+1,0,MPI_COMM_WORLD);
		MPI_Recv(&value[1],1,MPI_INT,rank+1,0,MPI_COMM_WORLD,&status);
		if(value[1]<value[0]) 
		{
		  value[0] = value[1];
		}
        printf("Rank %d: %d\n", rank, value[0]);
      	}
      else 
	{
		MPI_Recv(&value[1],1,MPI_INT,rank-1,0,MPI_COMM_WORLD,&status);
		MPI_Send(&value[0],1,MPI_INT,rank-1,0,MPI_COMM_WORLD);
		if(value[1]>value[0]) 
		{
		  value[0] = value[1];
		}
        printf("Rank %d: %d\n", rank, value[0]);
      	}
    }
    else 
    {
      if((rank%2 == 1) && (rank != (size-1))) 
	{
		MPI_Send(&value[0],1,MPI_INT,rank+1,0,MPI_COMM_WORLD);
		MPI_Recv(&value[1],1,MPI_INT,rank+1,0,MPI_COMM_WORLD,&status);
		if(value[1]<value[0]) 
		{
		  value[0] = value[1];
		}
        printf("Rank %d: %d\n", rank, value[0]);
      	}
      else if(rank != 0 && rank != (size-1)) 
	{
		MPI_Recv(&value[1],1,MPI_INT,rank-1,0,MPI_COMM_WORLD,&status);
		MPI_Send(&value[0],1,MPI_INT,rank-1,0,MPI_COMM_WORLD);
		if(value[1]>value[0]) 
		{
		  value[0] = value[1];
		}
        printf("Rank %d: %d\n", rank, value[0]);
      	}
    }
  } 

  MPI_Gather(&value[0],1,MPI_INT,arr,1,MPI_INT,0,MPI_COMM_WORLD);
  if(rank==0)
    {
	    printf("Sorted array: ");
	    for (i=0;i<size;i++) 
	    {
	      printf("%d ", arr[i]);
	    }
	    printf("\n");
    }
  MPI_Finalize();
  return 0;
}
