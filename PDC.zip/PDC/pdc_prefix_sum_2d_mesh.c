#include<stdio.h>
#include "mpi.h"
#include "math.h"

int main(int *argc,char **argv)
{
	
int i,rank,size,n,x,y;
MPI_Status status;

MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);
n = sqrt(size);

int a[n][n];

if(rank==0)
{
    for(i=0;i<n;i++)
	for(int j=0;j<n;j++)
	scanf("%d", &a[i][j]);
}

MPI_Scatter(a,1,MPI_INT, &x,1,MPI_INT,0,MPI_COMM_WORLD);


if(rank%n==0)
{
	//printf("Rank %d: %d\n",rank,x);
	MPI_Send(&x,1,MPI_INT,rank+1,0,MPI_COMM_WORLD);
}
else
{
	//printf("Rank %d: %d\n",rank,x);
	MPI_Recv(&y,1,MPI_INT,rank-1,0,MPI_COMM_WORLD,&status);

	x = x+y;
	if((rank+1)%n!=0)
	MPI_Send(&x,1,MPI_INT,rank+1,0,MPI_COMM_WORLD);

	//printf("Rank %d:Updated %d\n",rank,x);
}
MPI_Barrier(MPI_COMM_WORLD);

if(rank==n-1)
{
	MPI_Send(&x,1,MPI_INT,rank+n,1,MPI_COMM_WORLD);
}
else if((rank+1)%n==0)
{
	MPI_Recv(&y,1,MPI_INT,rank-n,1,MPI_COMM_WORLD,&status);

	x = x+y;
	if(rank != (n*n-1))
	MPI_Send(&x,1,MPI_INT,rank+n,1,MPI_COMM_WORLD);
}

MPI_Barrier(MPI_COMM_WORLD);

if((rank+1)%n==0 && rank!=(n*n-1))
{
	for(int i=1;i<n;i++)
	MPI_Send(&x,1,MPI_INT,rank+i,2,MPI_COMM_WORLD);
}
else if(rank>=n && (rank+1)%n!=0)
{
	MPI_Recv(&y,1,MPI_INT,((rank/n)*n - 1),2,MPI_COMM_WORLD,&status);
	
	x = x+y;	
}

MPI_Barrier(MPI_COMM_WORLD);

MPI_Gather(&x,1,MPI_INT,a,1,MPI_INT,0,MPI_COMM_WORLD);

if(rank==0)
{
	printf("Prefix Sum Matrix\n");
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		printf("%d ",a[i][j]);
		printf("\n");
	}
}


MPI_Finalize();

return 0;
}
