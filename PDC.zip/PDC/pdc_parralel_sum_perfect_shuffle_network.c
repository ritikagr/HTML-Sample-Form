#include<stdio.h>
#include "mpi.h"
#include<math.h>
#define comm MPI_COMM_WORLD
int main(int *argc,char **argv)
{

int i,rank,size,n,x,y,z;

MPI_Status status;

MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);

n = size;

int a[n];

if(rank==0)
{
printf("Enter array elements\n");
for(i=0;i<n;i++)
scanf("%d", &a[i]);
}

MPI_Scatter(a,1,MPI_INT,&x,1,MPI_INT,0,MPI_COMM_WORLD);

int m = log2(n);
if(pow(2,m)<n)
m++;

for(i=0;i<m;i++)
{
	if(rank==0 || rank==(n-1))
	y = x;

	if(rank<n/2 && rank!=0)
	MPI_Send(&x,1,MPI_INT,rank*2,0,MPI_COMM_WORLD);
	else if(rank!=0 && rank!=(n-1))
	MPI_Send(&x,1,MPI_INT,(rank-n/2)*2+1,0,MPI_COMM_WORLD);
	//printf("d\n");
	if(rank%2==0 && rank!=0)
	MPI_Recv(&y,1,MPI_INT,rank/2,0,comm,&status);
	else if(rank!=0 && rank!=(n-1))
	MPI_Recv(&y,1,MPI_INT,(rank-1)/2 + n/2,0,comm,&status);

	if(rank%2==0)
	MPI_Send(&y,1,MPI_INT,rank+1,1,MPI_COMM_WORLD);
	else
	MPI_Send(&y,1,MPI_INT,rank-1,1,MPI_COMM_WORLD);

	if(rank%2==0)
	MPI_Recv(&z,1,MPI_INT,rank+1,1,MPI_COMM_WORLD,&status);
	else
	MPI_Recv(&z,1,MPI_INT,rank-1,1,MPI_COMM_WORLD,&status);

	x = y+z;

	//printf("Step %d: Rank %d:%d\n",i,rank,x);

	MPI_Barrier(MPI_COMM_WORLD);
}

MPI_Barrier(MPI_COMM_WORLD);

if(rank==0)
{
	printf("Parallel sum using perfect shuffle network is: ");
	printf("%d\n",x);
}

MPI_Finalize();

return 0;
}
