#include <stdio.h>
#include "mpi.h"

int main(int argc, char **argv)
{
  int numtasks,rank,numworkers,source,dest,rows,offset,i,j,k,n;
  MPI_Status status;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &numtasks);

  numworkers = numtasks-1;

  /*---------------------------- master ----------------------------*/
  if (rank == 0) {
    
    printf("Enter Size of Matrix: ");
    scanf("%d", &n);
 
    int a[n][n],b[n][n],c[n][n];

    printf("Enter Matrix A:\n");    
    for (i=0; i<n; i++) {
      for (j=0; j<n; j++) {
        scanf("%d", &a[i][j]);
      }
    }

    printf("Enter Matrix B:\n");
    for (i=0; i<n; i++) {
      for (j=0; j<n; j++) {
        scanf("%d", &b[i][j]);
      }
    }

    /* send matrix data to the worker tasks */
    rows = n/numworkers;
    offset = 0;

    for (dest=1; dest<=numworkers; dest++)
    {
      MPI_Send(&n,1,MPI_INT, dest, 1, MPI_COMM_WORLD);
      MPI_Send(&offset, 1, MPI_INT, dest, 1, MPI_COMM_WORLD);
      MPI_Send(&rows, 1, MPI_INT, dest, 1, MPI_COMM_WORLD);
      MPI_Send(&a[offset][0], rows*n, MPI_DOUBLE,dest,1, MPI_COMM_WORLD);
      MPI_Send(&b, n*n, MPI_DOUBLE, dest, 1, MPI_COMM_WORLD);
      offset = offset + rows;
    }

    /* wait for results from all worker tasks */
    for (i=1; i<=numworkers; i++)
    {
      source = i;
      MPI_Recv(&offset, 1, MPI_INT, source, 2, MPI_COMM_WORLD, &status);
      MPI_Recv(&rows, 1, MPI_INT, source, 2, MPI_COMM_WORLD, &status);
      MPI_Recv(&c[offset][0], rows*n, MPI_DOUBLE, source, 2, MPI_COMM_WORLD, &status);
    }

    printf("Here is the result matrix:\n");
    for (i=0; i<n; i++) {
      for (j=0; j<n; j++)
        printf("%d ", c[i][j]);
      printf ("\n");
    }

  }

  /*---------------------------- worker----------------------------*/
  if (rank > 0) {
    source = 0;
    MPI_Recv(&n, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &status);
    int a[n][n],b[n][n],c[n][n];
    MPI_Recv(&offset, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &status);
    MPI_Recv(&rows, 1, MPI_INT, source, 1, MPI_COMM_WORLD, &status);
    MPI_Recv(&a, rows*n, MPI_DOUBLE, source, 1, MPI_COMM_WORLD, &status);
    MPI_Recv(&b, n*n, MPI_DOUBLE, source, 1, MPI_COMM_WORLD, &status);

    /* Matrix multiplication */
    for (k=0; k<n; k++)
      for (i=0; i<rows; i++) {
        c[i][k] = 0.0;
        for (j=0; j<n; j++)
          c[i][k] = c[i][k] + a[i][j] * b[j][k];
      }


    MPI_Send(&offset, 1, MPI_INT, 0, 2, MPI_COMM_WORLD);
    MPI_Send(&rows, 1, MPI_INT, 0, 2, MPI_COMM_WORLD);
    MPI_Send(&c, rows*n, MPI_DOUBLE, 0, 2, MPI_COMM_WORLD);
  }

  MPI_Finalize();
}
