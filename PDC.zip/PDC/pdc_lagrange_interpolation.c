#include<mpi.h>
#include<stdio.h>
#include<stdlib.h>

int main(int argc,char** argv)
{
	MPI_Init(&argc,&argv);
	int world_size,world_rank;
	MPI_Comm_size(MPI_COMM_WORLD,&world_size);
	MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);
	int n,i,j,k;
	float x[world_size],y[world_size],liyi[world_size];
	float v;
	if(world_rank == 0)
	{
		n = world_size;
		printf("Enter x values\n");
		for(i = 0;i<n;i++)
		{
			scanf("%f",&x[i]);
		}
		//y = (float*)malloc(sizeof(float)*n);
		printf("Enter y values\n");
		for(i = 0;i<n;i++)
		{
			scanf("%f",&y[i]);
		}
		printf("Enter the value at which lagrangian is to be calculated\n");
		scanf("%f",&v);
		printf("All inputs done\n");
		//liyi = (float*)malloc(sizeof(float)*n);
		MPI_Bcast(x,n,MPI_FLOAT,0,MPI_COMM_WORLD);
		MPI_Bcast(&v,1,MPI_FLOAT,0,MPI_COMM_WORLD);
	}
	
	int yi;
	MPI_Scatter(y,1,MPI_FLOAT,&yi,1,MPI_FLOAT,0,MPI_COMM_WORLD);
	printf("In process %d\n",world_rank);
	float num = 1,den = 1,li;
	for(i = 0;i<n;i++)
	{
		num = num*(v-x[i]);
		if(i != world_rank)
		den = den*(x[world_rank]-x[i]);
	}
	li = num/den;
	yi = li*yi;
	MPI_Gather(&yi,1,MPI_FLOAT,liyi,1,MPI_FLOAT,0,MPI_COMM_WORLD);

	if(world_rank == 0)
	{
		float sum = 0;
		for(i = 0;i<n;i++)
		{
			sum += liyi[i];
		}
		printf("Lagrangian value = %f\n",sum);
	}
}
