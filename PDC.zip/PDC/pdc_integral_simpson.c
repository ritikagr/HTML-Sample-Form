#include <stdio.h>
#include "mpi.h"

int main(int argc, char **argv)
{
  double integral=0;
  double a, b,totalintegral;
  int n;
  double h;
  double x;
  int i, rank, size;

  double f(double x);
  MPI_Status status;

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  
  if(rank == 0) {
    printf("Enter a, b, and n\n");
    scanf("%lf %lf %d", &a, &b, &n);
  }
  MPI_Bcast(&a,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
  MPI_Bcast(&b,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
  MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);

  h = (b - a)/(double)n;
  if(rank == 0) {
    integral = f(a) + f(b);
  }
  else
  {
	  x = a + h*rank;
	  int i = rank;
	  for(; x < b; x+=h*(size-1)) {
	    if(i & 1)
	    integral += 4*f(x);
	    else
	    integral += 2*f(x);
	
	    i += (size-1);
	  }
  }

  MPI_Reduce(&integral,&totalintegral,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
  totalintegral *= (h/3.0);

  if(rank == 0) {
    printf("With n = %d trapezoids, the estimate ",n);
    printf("of the integral from %lf to %lf = %lf\n", a, b, totalintegral);
  }

  MPI_Finalize();

  return 0;
}

double f(double x) {
  return x;
  //return x * x * x;
  //return 1 / x;
}
