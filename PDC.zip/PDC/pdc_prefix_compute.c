#include<stdio.h>
#include "mpi.h"

int main(int argc,char **argv)
{
int my_rank,proc,source,dest,n;
MPI_Status status;
int psum,a;
//int n = 5;

//int A[5] = {1,2,3,4,5};
MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
MPI_Comm_size(MPI_COMM_WORLD, &proc);

if(my_rank == 0)
{

scanf("%d",&n);
printf("Enter elements: ");
int A[n];

for(int i=0;i<n;i++)
scanf("%d", &A[i]);

for(int i=0;i<n;i++)
printf("%d \n", A[i]);

for(int i=1;i<n;i++)
{
MPI_Send(&A[i],1,MPI_INT,i,0,MPI_COMM_WORLD);
}

psum = A[0];

printf("Prefix Sum Computed by Process 0 is: %d\n", psum);

MPI_Send(&psum,1,MPI_INT,1,1,MPI_COMM_WORLD);

}
else
{

MPI_Recv(&a,1,MPI_INT,0,0,MPI_COMM_WORLD, &status);
MPI_Recv(&psum,1,MPI_INT,my_rank-1,1,MPI_COMM_WORLD, &status);

psum += a;

printf("Prefix Sum Computed by Process %d is: %d\n",my_rank, psum);

if(my_rank!=(proc-1))
MPI_Send(&psum,1,MPI_INT,my_rank+1,1,MPI_COMM_WORLD);
}

MPI_Finalize();

return 0;
}
