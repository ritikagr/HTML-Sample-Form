#include <stdio.h>
#include <mpi.h>

#define send_data_tag 2001
#define return_data_tag 2002

int main(int argc, char **argv) 
{
long int sum, partial_sum;
MPI_Status status;
int my_rank, root_process, i, size, num_procs, num_ele_to_receive, avg_ele_per_process, sender, num_ele_received, l, r, num_ele_to_send;

MPI_Init(&argc, &argv);

root_process = 0;

MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
MPI_Comm_size(MPI_COMM_WORLD, &num_procs);

if(my_rank == root_process) {
 
	printf("please enter the number of numbers to sum: ");
	scanf("%d", &size);

	int array[size];

	avg_ele_per_process = size/num_procs;
	if(avg_ele_per_process*num_procs < size)
	avg_ele_per_process++;

	for(i = 0; i < size; i++) {
	scanf("%d",&array[i]);
	}

	for(i = 1; i < num_procs; i++) {
	l = i*avg_ele_per_process;
	r = (i + 1)*avg_ele_per_process-1;

	if((size - r) < 0)
	r = size - 1;

	num_ele_to_send = r - l + 1;

	MPI_Send( &num_ele_to_send, 1 , MPI_INT, i, send_data_tag, MPI_COMM_WORLD);

	MPI_Send( &array[l], num_ele_to_send, MPI_INT, i, send_data_tag, MPI_COMM_WORLD);
	}

	sum = 0;
	for(i = 0; i < avg_ele_per_process; i++) {
	sum += array[i];   
	} 

	printf("partial sum %i calculated by root process\n", sum);

	for(i = 1; i < num_procs; i++) {

	MPI_Recv(&partial_sum, 1, MPI_LONG, MPI_ANY_SOURCE, return_data_tag, MPI_COMM_WORLD, &status);

	sender = status.MPI_SOURCE;

	printf("Partial sum %i returned from process %i\n", partial_sum, sender);

	sum += partial_sum;
	}

	printf("The grand total is: %i\n", sum);
}
else
{

	MPI_Recv( &num_ele_to_receive, 1, MPI_INT, root_process, send_data_tag, MPI_COMM_WORLD, &status);
	 
	int array2[num_ele_to_receive];

	MPI_Recv( &array2, num_ele_to_receive, MPI_INT, root_process, send_data_tag, MPI_COMM_WORLD, &status);

	num_ele_received = num_ele_to_receive;

	 partial_sum = 0;
	 for(i = 0; i < num_ele_received; i++) {
	    partial_sum += array2[i];
	 }

	MPI_Send( &partial_sum, 1, MPI_LONG, root_process, return_data_tag, MPI_COMM_WORLD);
}

MPI_Finalize();

return 0;
}
