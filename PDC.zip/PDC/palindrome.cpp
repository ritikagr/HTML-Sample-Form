#include <bits/stdc++.h>
using namespace std;

#define ll long long int

int main ()
{
        string str = "";
        cin >> str;

        int len = str.length();

        for(int i=len-1;i>=0;i--)
        {
                string tp = str.substr(i,len-i);

                string tpp = tp;
                reverse(tpp.begin(),tpp.end());
                cout << tp;
                if(tp==tpp)cout << endl << "palindrome" << endl;
                else cout << endl << "Not palindrome" << endl;

        }

        return 0;
}

