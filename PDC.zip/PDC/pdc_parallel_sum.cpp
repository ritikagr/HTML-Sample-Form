#include<bits/stdc++.h>
#include<string.h>
#include "mpi.h"

using namespace std;

int main(int argc,char *argv[])
{
int my_rank;
int p;
int source;
int dest;
int tag=0;
int n;
scanf("%d",&n);

int A[n];
int i;
for(i=0;i<n;i++)
scanf("%d",&A[i]);
int sum=0;
int total=0;
MPI_Status status;
MPI_Init(&argc,&argv);
MPI_Comm_rank(MPI_COMM_WORLD,&my_rank);
MPI_Comm_size(MPI_COMM_WORLD,&p);

if(my_rank!=0)
{
sum=0;
for(i=(my_rank-1)*(n/p);i<min((my_rank*(n/p)), n);i++)
sum+=A[i];

dest=0;
MPI_Send(sum,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
}
else if(my_rank==0)
{
for(source=1;source<p;source++)
{
MPI_Recv(sum,1,MPI_INT,source,tag,MPI_COMM_WORLD,&status);
printf("Sum received from process %d is: %d\n",status.MPI_SOURCE, sum);
total += sum;
}

cout<<"final sum is "<<total<<endl;
}

MPI_Finalize();

return 0;
}
