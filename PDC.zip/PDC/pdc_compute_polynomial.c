#include<stdio.h>
#include "mpi.h"
#include<math.h>
#define comm MPI_COMM_WORLD
int main(int *argc,char **argv)
{

int i,rank,size,n,e,x,y,z,b;
int sum=0;

MPI_Status status;

MPI_Init(&argc, &argv);
MPI_Comm_rank(MPI_COMM_WORLD, &rank);
MPI_Comm_size(MPI_COMM_WORLD, &size);

n = size;

int a[n];
int mask[n];
if(rank==0)
{
printf("Enter array elements\n");
for(i=0;i<n;i++)
{
scanf("%d", &a[i]);
if(i%2==0)
mask[i]=0;
else
mask[i]=1;
}

printf("Enter element e: ");
scanf("%d",&e);
}

MPI_Scatter(a,1,MPI_INT,&b,1,MPI_INT,0,MPI_COMM_WORLD);
MPI_Scatter(mask,1,MPI_INT,&x,1,MPI_INT,0,MPI_COMM_WORLD);
MPI_Bcast(&e,1,MPI_INT,0,comm);

int m = log2(n);
if(pow(2,m)<n)
m++;

for(i=0;i<m;i++)
{
	if(x==1)
	b = b*e;

	MPI_Barrier(comm);
	
	if(rank==0 || rank==(n-1))
	y = x;

	if(rank<n/2 && rank!=0)
	MPI_Send(&x,1,MPI_INT,rank*2,0,MPI_COMM_WORLD);
	else if(rank!=0 && rank!=(n-1))
	MPI_Send(&x,1,MPI_INT,(rank-n/2)*2+1,0,MPI_COMM_WORLD);
	//printf("d\n");
	if(rank%2==0 && rank!=0)
	MPI_Recv(&y,1,MPI_INT,rank/2,0,comm,&status);
	else if(rank!=0 && rank!=(n-1))
	MPI_Recv(&y,1,MPI_INT,(rank-1)/2 + n/2,0,comm,&status);

	x = y;
	e = e*e;
}

MPI_Barrier(MPI_COMM_WORLD);

MPI_Reduce(&b,&sum,1,MPI_INT,MPI_SUM,0,comm);

if(rank==0)
{
	printf("Polynomial Result: %d\n",sum);
}

MPI_Finalize();

return 0;
}
