#include<stdio.h>
#include "mpi.h"

int main(int argc, char** argv)
{
    int size, rank,n,m;
    MPI_Status Stat;
 
    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
 
    if (rank == 0)
    {
	printf("Enter values of n and m:\n");
	scanf("%d %d",&n,&m);

        int a[n][m];
        int b[m];
        int c[n];
	
	printf("Enter Matrix A:\n");
        for(int i=0;i<n;i++)
        {
            for (int j=0;j<m;j++)
            {
                scanf("%d", &a[i][j]);
            }
        }

	printf("Enter Vector B :\n");
	for(int i=0;i<m;i++)
	scanf("%d", &b[i]);
 
        printf("Matrix A :\n");
        for (int i=0;i<n;i++)
        {
            for (int j=0;j<m;j++)
            {
                printf("%d ", a[i][j]);
            }
            printf("\n");
        }
        printf("Vector B :\n");
        for (int i=0;i<m;i++)
        {
            printf("%d ", b[i]);
        }
        printf("\n");
 
        for (int j=1;j<size;j++)
        {
	    MPI_Send(&n, 1, MPI_INT, j, 0, MPI_COMM_WORLD);
            MPI_Send(&m, 1, MPI_INT, j, 1, MPI_COMM_WORLD);
            MPI_Send(b, m, MPI_INT, j, 99, MPI_COMM_WORLD);
        }
 
        for (int i=1;i<size;i++)
        {
            MPI_Send(a[i-1], m, MPI_INT, i, (100*(i+1)), MPI_COMM_WORLD);
        }
 
        /* (3) Gathering the result from other processes*/
        for (int i=1;i<size;i++)
        {
            MPI_Recv(&c[i-1], 1, MPI_INT, i, i, MPI_COMM_WORLD, &Stat);
            printf("P%d : c[%d] = %d\n", rank, i-1, c[i-1]);
        }
    }
    else
    {

	MPI_Recv(&n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &Stat);
        MPI_Recv(&m, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &Stat);
        int b[m];
 
        MPI_Recv(b, m, MPI_INT, 0, 99, MPI_COMM_WORLD, &Stat);
 
        int buffer[m];
        MPI_Recv(buffer, m, MPI_INT, 0, (100*(rank+1)), MPI_COMM_WORLD, &Stat);
        int sum = 0;
        for (int j=0;j<m;j++)
        {
            sum = sum + (buffer[j] * b[j]);
        }
        MPI_Send(&sum, 1, MPI_INT, 0, rank, MPI_COMM_WORLD);
    }
 
    MPI_Finalize();
    return 0;
}
